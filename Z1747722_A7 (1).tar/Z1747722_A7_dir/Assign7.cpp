/*
Robert Dominique
Z1747722
Due 12/2/2019



This assignment involves maintaining a File Allocation Table.

We will simulate "FAT-12" on a (very small) disk. Each block will be 512 bytes in size. With FAT-12, we have 4096 blocks, so the disk is only 2 MB in size.

Starting with an empty root directory, we will carry out a series of transactions. From time to time we will print the contents of the directory and (part) of the FAT.

Write a program in C or C++ on the turing system to accomplish this.  Designing your program is largely up to you.

----------------------------------------------------------------

Input File

The data in the input file is in lines.  Each line begins with 1 letter indicating the type of transaction involved. After that are more items (file name, file size) as described below.

The file ends with a line starting with '?'.  This is present as a delimiter.
The file can be found here:

/home/turing/t90hch1/csci480/Assign7/data7.txt

----------------------------------------------------------------

What to do

The main loop of the program does the following:

Read the letter indicating which transaction is next.  After that, depending on the kind of transaction, read the rest of the data for that transaction.

Type 'C':  Copy File transaction.  The line also contains the file name and the name of the new file.

Search for the file name.  If it does not exist, we have an error.
Search for the new file name.  If it already exists, we have an error.  Create a new directory entry with the new name and the same size and then allocate space for it.

Type 'D':  Delete File transaction.  The line also contains the file name.  Search for the file name.  If it does not exist, we have an error.  Remove the directory entry for this file and deallocate the space it was using.

Type 'N':  New File transaction.  The line also contains the file name and the file size.

Search for the file name.  If it already exists, we have an error.
Create a directory entry with this name and size and then allocate space for it.

Type 'M':  Modify File transaction.  The line also contains the file name and the new file size.

Search for the file name.  If it does not exist, we have an error.
After that, the easiest way to do a Modify transaction is to use the other kinds of transactions:  New to make a new file with a temporary file name and the new size; Delete to get rid of the old file; and Rename to change the temporary file name to the name of the old file.

Type 'R':  Rename File transaction.  The line also contains the old file name and the new file name.

Search for the old file name.  If it does not exist, we have an error.  Search for the new file name.  If it already exists, we have an error.  Change the name.

Type '?":  The run ends.

----------------------------------------------------------------

Items you will probably need

You will need a table of short integers to be the FAT itself, all initialized to 0.

You will need a data structure to contain the directory entries. I suggest defining a class or struct called Entry and then having a linked list or array (or whatever) of Entry instances.  Maintain the order (chronological) of the entries.  A directory entry contains (at least) the following items:

--- the file name
--- the file size
--- the number of the first block for that file

Define a constant to represent the value 512, the number of bytes in a block.

Define a constant called HOWOFTEN with the value 6.

Define a constant to represent 12, the maximum number of entries in a directory block.

You may want to define a constant to indicate how much of the FAT to print each time.  The eventual value should be 240, but it may be convenient to use smaller values for this constant and for HOWOFTEN in developing your program.

You may want to define a function for each kind of transaction and perhaps use a switch statement.  You will also need functions to print the directory and the FAT.  You may also need an assortment of little utility functions for purposes such as:

-- searching for a file name in the directory
-- deciding how many blocks a file needs, based on its size
-- finding the first free block
-- finding the last block used by a file


*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <vector>
#include "Assign7.h"

void change();
void allocate();
void allocateTable(Record*&);
void renameFile();
void deleteFile();
void deallocateTable(Record*&);
void copyFile();
void printTable();
void removeRecords(Record&);
void printRecords();
Record* search(string);

short counter = 0;

//const variables for printing record size


const unsigned HOW_OFTEN = 5;
const unsigned COLUMN = 20;
const unsigned MAX = 12;

vector<vector<short>> Table(COLUMN);
vector<Record> records;
fstream file;


int main(int argc, const char * argv[]) {

    Record* directory = new Record(".", 512);
    directory->index.push_back(std::pair<short, short>(0,0));
    directory->clusters.push_back(0);
    records.push_back(*directory);

    Record* parent = new Record("..", 0);
    records.push_back(*parent);

    for (unsigned R = 0; R < Table.size(); R++) {
        Table[R].resize(12);
    }

    Table[0][0] = -1;

    file.open("data7.txt");

    if (!file.is_open()) {
        cout << "File did not open, terminating program.";
        return -1;
    }

    char symbol = ' ';
    printRecords();
    printTable();

    while (symbol != '?') {

        file >> symbol;
        if (counter == HOW_OFTEN) {
            printRecords();
            printTable();
            counter = 0;
        }

        switch (symbol) {
            case 'N':
                allocate();
                break;
            case 'C':
                copyFile();
                break;
            case 'M':
                change();
                break;
            case 'D':
                deleteFile();
                break;
            case 'R':
                renameFile();
                break;
            default:
                break;
        }
        counter++;
    }
    printRecords();
    printTable();

    return 0;
}

/***************************************************
  This function changes the file
 ***************************************************/
void change() {
    string name;
    unsigned size;
    file >> name;
    file >> size;
    Record* record=search(name);

    cout << "\nTransaction, modify file.\n";
    if (record == nullptr)
    {
        cout << "Error, file not found.\n";
        return;
    }

    if (record->bytes > size)
    {
        record->resize(size);
        deallocateTable(record);

    }
    else if (record->bytes < size)
    {
        record->resize(size);
        allocateTable(record);
    }


    std::cout << "Successfully modified a file, " << name << "\n";
}

/***************************************************
 This function allocates memory for the records
 ***************************************************/
void allocate() {
    string name;
    unsigned size;
    file >> name;
    file >> size;
    cout << "\nTransaction, add a new file." << endl;
    Record* record = search(name);
    if (record != nullptr) {
        cout << "Error, a current file already has that name." << endl;
        return;
    }

    //create new Record
    record = new Record(name, size);
    records.push_back(*record);
    //check for directory limit
    if ((records.size() - 1) % MAX == 0) {
        Record* directory = &records[0];
        directory->resize(directory->bytes + CLUSTER);
        allocateTable(directory);
    }

    if (size != 0) {
        Record* record = &records.back();
        allocateTable(record);
    }

    cout << "Successfully added a new file, " << name << ", of size " << size << endl;
}

/***************************************************
  This function allocates memory for the Table
 ***************************************************/
void allocateTable(Record *&record) {

    unsigned size = record->sizeOfCluster;
    unsigned long count = record->index.size();

    if (size == 0) {
        return;
    }

    unsigned separate = 0;

    //nested for loop to search through FAT table
    for (unsigned P = 0; P < COLUMN; P++)
    {
        for (unsigned M = 0; M < MAX; M++)
        {
            //if count is less than size
            if (count < size)
            {
                if (Table[P][M] == 0)
                {
                    record->index.push_back(std::pair<short, short>(P, M));
                    record->clusters.push_back(separate);
                    count++;
                }
                separate++;
            }
            else
            {
                M = MAX;
                P = COLUMN;
            }
        }
    }

    std::pair<short, short>location;
    int N = 0;
    while( N < record->sizeOfCluster - 1)
    {
        location = record->index[N];
        Table[location.first][location.second] = record->clusters[N+1];
       N++;
    }

    location = record->index[N];
    Table[location.first][location.second] = -1;
}

/***************************************************
  This function renames a file
 ***************************************************/
void renameFile() {


    string name;
    string newName;
    file >> name;
    file >> newName;
    Record* record=search(name);
    if (record==nullptr)
        return;

    record->filename = newName;
    cout << "\nTransaction: Rename a file";
    cout << "\nSuccessfully renamed file " << name << " to " << newName << ".\n";
}

/***************************************************
 This function deallocates the size of a cluster
 ***************************************************/
void deleteFile() {

    string name;
    file >> name;
    Record* record=search(name);

    cout << "\nTransaction: Delete a file.\n";
    if (record == nullptr)
    {
        cout << "Error, file not found.\n";
        return;
    }

    record->sizeOfCluster = -1;
    deallocateTable(record);
    cout << "Successfully deleted a file, " << record->filename << "\n";
    removeRecords(*record);
}

/***************************************************
 This method deallocates the FAT memory
 ***************************************************/
void deallocateTable(Record*& record) {

    int size = record->sizeOfCluster;
    long count = record->index.size() - 1;
    pair<short, short>location;
    while(count >= size)
    {
        if (count == -1)
            return;

        location = record->index[count];
        Table[location.first][location.second] = 0;
        record->index.pop_back();
        count--;
    }
    if (record->index.size() != 0)
    {
        location = record->index[count];
        Table[location.first][location.second] = -1;
    }
    record->clusters.resize(size);
}

/***************************************************
  This function copies the files
 ***************************************************/
void copyFile() {

    string name;
    string copy;
    file >> name;
    file >> copy;
    Record* record = search(name);

    cout << "\nTransaction: Copy a file.\n";

    if (record == nullptr)
    {
        cout << "Error, source file does not exists.\n";
        return;
    }

    Record* copyRecord = search(copy);

    if (copyRecord != nullptr)
    {
        cout << "Error, destination file already exists.\n";
        return;
    }

    copyRecord = new Record(copy, record->bytes);

    allocateTable(copyRecord);
    records.push_back(*copyRecord);
    cout << "Successfully copied an existing file, " << record->filename << " to a new file, " << copyRecord->filename << " \n";
}


/***************************************************
 This function searchs the name of a file and returns a pointer to an record struct or null.
 ***************************************************/
Record* search(std::string name)
{

    for (unsigned i = 0; i < records.size(); i++)
    {
        if (name == records[i].filename)
            return &records[i];
    }

    return nullptr;//return null
}


/***************************************************
  This function removes an record from the reocrds vector. Takes a reference to an reocrd as an argument
 ***************************************************/
void removeRecords(Record& record)
{
    vector<Record>::iterator iter;
    for (iter = records.begin(); iter != records.end(); iter++)
    {
        if (iter->filename == record.filename)
        {
            records.erase(iter);
            return;
        }
    }
}


void printRecords()
{
    cout << "\nDirectory Listing" << endl;

    for (unsigned i = 0; i < records.size(); i++)
    {
        cout << "\nFile Name: " << records[i].filename << "      Size: "<< records[i].bytes;
        cout << "\nClusters in use: ";
        records[i].printClusters();
    }
}


/***************************************************
  This function prints out the FAT table and total file and byte size
 ***************************************************/
void printTable()
{
    int total = 0;

    for (unsigned i = 0; i < records.size(); i++)
    {
        total += records[i].bytes;
    }
    cout << "\nTotal File Size: " << records.size() << "    Total Byte Size: " << total;
    cout << "\n" << endl;
    cout << endl << "Contents of the File Allocation Table" << endl << endl;

    for (unsigned i = 0; i < COLUMN; i++)
    {
        for (unsigned j = 0; j < MAX; j++)
        {
            //print clusters
            cout << std::setw(8) << Table[i][j];
            if (j == 11)
            {
                cout << "\n";
            }
        }
    }
}

