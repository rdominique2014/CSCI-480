#ifndef ASSIGN7_H
#define ASSIGN7_H
#include <string>
#include <vector>
#include <iostream>
using namespace std;

const double CLUSTER = 512;

struct Record {
    string filename;
    vector<short>clusters;
    vector<pair<short, short>> index;
    unsigned bytes;
    int sizeOfCluster;

    Record(string name, unsigned size) {
        filename = name;
        this->bytes = size;
        findClusterSize();
    }

    void findClusterSize() {
        if (bytes != 0) {
            int total = 1 + (((double)bytes) / CLUSTER);
            sizeOfCluster = total;
        }
        else {
            sizeOfCluster = 0;
        }
    }

    void resize(unsigned Bytes) {
        if (Bytes != 0) {
            int total = 1 + (((double)Bytes) / CLUSTER);
            sizeOfCluster = total;
            bytes = Bytes;
            return;
        }
        else {
            sizeOfCluster = -1;
            bytes = 0;
            clusters.clear();
        }
    }

    void printClusters() {
        if (clusters.size() == 0) {
            cout << "(none)";
        }

        for (unsigned U = 0; U < clusters.size(); U++) {
            cout << clusters[U] << " ";
        }
        cout << endl;
    }

};

#endif

