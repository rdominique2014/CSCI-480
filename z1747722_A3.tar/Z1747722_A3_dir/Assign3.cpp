/*
Robert Dominique
Z1747722
Sep 28, 2019
CSCI 480 -2


In this assignment, you will implement a microshell in C/C++.

Print a prompt "480shell>" and wait for input.

--- Read the input typed after the prompt.

--- Execute the command typed in after the prompt and print a new
    prompt.

--- The shell understands the commands "quit" and "q" as the special
    commands to exit.

--- The shell understands a special symbol "||", by which you can
    pipe the output of one command to next command.  To simplify,
    this assignment only requires one pipe between two commands, such
    as in:




*/

#include <iostream>
#include <sys/types.h>
#include <sstream>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

using namespace std;





#define BUFFER_SIZE 1024
#define PIPE_SIZE 2






void Input1Command(int _pipe[], char *command1[], const bool pipeDone);
void Input2Command(int _pipe[], char *command2[]);







int main() {
    char *personCommand[BUFFER_SIZE] = {NULL, NULL, NULL};
    char *personCommand2[BUFFER_SIZE] = {NULL, NULL, NULL};
    char buffer[BUFFER_SIZE]; //This will hold the input from the user

    int home, home2;
    int mainPipe[PIPE_SIZE];
    pid_t firstFork, secondFork = 0;

    cout << "480shell> "; // The shell

    while (fgets(buffer, BUFFER_SIZE, stdin) != NULL) {

// User input until none is entered
        bool usersPipe = false;

        buffer[strlen(buffer) - 1] = 0;

        int user = 0;
        char *bufferPtr;
        bufferPtr = strtok(buffer, " ");

        while (bufferPtr != NULL) {
            if ((strcmp(bufferPtr, "q") == 0) || (strcmp(bufferPtr, "quit") == 0)) {
                cout << "We are exiting the shell..." << endl << endl;
                return 0;
            }
            if (strcmp(bufferPtr, "||") == 0) {
                usersPipe = true;
                user = 0;
                bufferPtr = strtok(NULL, " ");
            }
            if (!usersPipe) {
                personCommand[user] = bufferPtr;
                bufferPtr = strtok(NULL, " ");
                user++;
            }
            else {
                personCommand2[user] = bufferPtr;
                bufferPtr = strtok(NULL, " ");
                user++;
                int value = pipe(mainPipe);

                if (value == -1) {
                    cout << "The pipe failed..." << endl;
                }

            }
        }

        firstFork = fork();
        if (firstFork < 0) {
            cerr << "The first fork failed." << endl;
            return -1;
        }
        if (firstFork == 0) {
            Input1Command(mainPipe, personCommand, usersPipe);
        }

        if (usersPipe) {
            secondFork = fork();
            if (secondFork == 0) {
                Input2Command(mainPipe, personCommand2);
            }
            if (secondFork < 0) {
                cerr << "The second fork failed " << endl << endl;
                return -1;
            }
        }
        if (usersPipe) {
            close(mainPipe[1]);
            close(mainPipe[1]);
        }

        firstFork = waitpid(firstFork, &home, 0);
        if (firstFork < 0) {
            cerr << "Waiting for first child." << endl;
            return -1;
        }
        if (usersPipe) {
            secondFork = waitpid(secondFork, &home2, 0);
            if (secondFork < 0) {
                cerr << "Waiting for second child." << endl << endl;
                return -1;
            }
        }
        cout << "480shell> "; //Header for the shell
    }
    return 0;
}

void Input1Command(int _pipe[], char *command1[], const bool pipeDone) {
    if (pipeDone) {
        int value2 = dup2(_pipe[1], 1);

        if (value2 < 0) {
            cerr << "An error occured" << endl;
            exit(-1);
        }
        close(_pipe[0]); //close the pipe
    }

    int value = execvp(command1[0], command1);

    if (value < 0) {
        cerr << "The first command could not be executed!" << endl;
        exit(-1);
    }
}


void Input2Command(int _pipe[], char *command2[]) {

    int value2 = dup2(_pipe[0], 0);

    if (value2 < 0) {
        cerr << "Error occurred" << endl;
        exit(-1);
    }

    close(_pipe[1]);

    int value = execvp(command2[0], command2);

    if (value < 0) {
        cerr << "The second command could not be executed" << endl;
        exit(-1);
    }
}

