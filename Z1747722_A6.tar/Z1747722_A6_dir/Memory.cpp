#include "Memory.h"

Memory::Memory(int firstArea, int blockSize) {
    this->firstArea = firstArea;
    this->blockSize = blockSize;
}


Memory::Memory(int firstArea, int blockSize, string processID, string memoryBlockID) {
    this->firstArea = firstArea;
    this->blockSize = blockSize;
    this->processID = processID;
    this->memoryBlockID = memoryBlockID;
}

