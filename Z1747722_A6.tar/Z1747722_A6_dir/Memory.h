#ifndef Memory_h
#define Memory_h

#include <string>
#include <list>

using std::string;
using std::list;

class Memory {
public:
    int firstArea, blockSize;

    string processID;
    string memoryBlockID;

    Memory(int, int, string, string);
    Memory(int, int);
};

#endif /* Memory_h */

