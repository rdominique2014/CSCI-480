/*
Robert Dominique
Z1747722
Assignment 6
Due 11/13/19

In this assignment, we are simulating memory management.  When a process is loaded into memory or a process requests a block of memory dynamically, the system must allocate memory, and when a process terminates or frees memory previously requested, the system must  deallocate memory.

For the sake of this assignment, we will assume we have a small computer with only 16 MB of memory.  We will assume that the operating system uses the first 3 MB, leaving 13 MB for applications.  Starting at that point, we will process several kinds of transactions:

--- Load a process into memory
--- Allocate a block of memory dynamically
--- Deallocate a block obtained earlier
--- Terminate a process, freeing all its memory

From time to time, we will print out the contents of the data
structures involved.

A description of the input file is provided below.

Write a program in C++ on the turing system to accomplish this.  Your
program (which may be in several files) should do the following:

--- Define a class or struct to represent one block of memory.  It should include the starting address (an integer), the size (an integer), the process ID of the owner (a string, might be blank) and the ID of the block (a string, might be blank), as well as one or two pointers to blocks.

--- Use #define to create a constant which I shall call HOWOFTEN.
Give it the value 5.

--- Create two linked lists of blocks.  One list contains blocks that are presently in use, and the other contains blocks that are not presently in use.  I shall refer to these as InUse and Avail, respectively.

--- Initialize InUse to be empty.

--- Initialize Avail to consist of one 1 MB block, two 2MB blocks and two 4 MB blocks, in that order.  The starting address for the first block should be at 3*1024*1024.  (Again, we are assuming the operating system uses the first 3 megabytes of memory.  While it is 
loading, this memory management system is not yet in use, which is why we have these unconsolidated blocks on the list.)

--- Before any transactions, print the contents of both lists.

--- Open and read the input file and carry out the transactions.

--- Every HOWOFTEN transactions, reprint the contents of both lists.

--- After all transactions, reprint the contents of both lists.

--- Be sure you close the input file.


*/

#include "Assign6.h"

int main(int argc, const char * argv []) {
    if (argc > 2) {
        cerr << "Error: Too many arguments were entered!" << endl;
        exit(-1);
    }

    initialize();
    read(string(argv[1]));
    cancelCall();
    return 0;
}

void regulate() {
    Memory *currentSpot = *(available.begin());

    int lastArea = currentSpot->firstArea + currentSpot->blockSize;
    int firstArea;

    list<Memory*>::iterator it = available.begin();
    it++;

    while (it != available.end()) {
        currentSpot = *it;
        firstArea = currentSpot->firstArea;

        if (lastArea == firstArea) {
            int closeSize = currentSpot->blockSize;
            it--;

            Memory *nextSpot = *it;
            int newSize = nextSpot->blockSize + closeSize;

            if (newSize < 4 * MB) {
                cout << "Merging two blocks at " << nextSpot->firstArea << " and " << currentSpot->firstArea << endl;

                Memory *newSpot = new Memory(nextSpot->firstArea, newSize);
                available.erase(it++);

                delete (nextSpot);
                nextSpot = *it;

                available.erase(it++);
                delete (nextSpot);

                nextSpot = nullptr;
                available.insert(it, newSpot);
                lastArea = newSpot->firstArea + newSpot->blockSize;
            } else {
                it++;
                firstArea = firstArea + closeSize;
            }
        }
        lastArea = currentSpot->blockSize + firstArea;
        it++;
    }
}

void allocate(list<Memory*>::iterator it, string processID, int requiredMemorySize, string processName) {
    Memory *currentSpot = *it;
    Memory *memory = new Memory(currentSpot->firstArea, requiredMemorySize, processID, processName);
    int begin = currentSpot->firstArea + requiredMemorySize;
    inUse.push_front(memory);
    available.erase(it++);
    int remainingMemory = currentSpot->blockSize - requiredMemorySize;
    if (remainingMemory > 0) {
        Memory *memory2 = new Memory(begin, remainingMemory, "", "");
        available.insert(it, memory2);
    }
}

void processLine(string line, string type) {
    istringstream inStream(line);
    string transactionType;

    inStream >> transactionType;

    cout << endl;

    if (transactionType == "L" || transactionType == "A") {
        string processName, processId;
        int blockSize;

        inStream >> processId;
        inStream >> blockSize;
        inStream >> processName;

        if (transactionType == "L") {
            cout << endl << "Transaction: Request to load process " << processId << ", Block ID " << processName << " using " << blockSize << " bytes of memory" << endl;
        } else {
            cout << endl << endl << "Transaction: Request to allocate additional " << blockSize << " bytes for process " << processId << ", " << "Block ID: " << processName << endl;
        }

        load(processId, blockSize, processName, type);
    } else if (transactionType == "D") {
        string processId, processName;
        inStream >> processId;
        inStream >> processName;

        cout << endl << endl << "Transaction: Request to Deallocate Block ID: " << processName << " for process " << processId << endl;
        deallocate(processId, processName, transactionType);
    } else {
        string processID;
        inStream >> processID;
        cout << endl << endl << "Transaction: Request to Terminate process " << processID << endl;
        cancelProcess(processID);
    }
}



void load(string processID, int blockSize, string processName, string transaction) {
    list<Memory*>::iterator it;
    if (transaction == "F") {
        it = firstFit(blockSize);
        if ( it == available.end()) {
            cerr << "Error: The attempt to allocate memory failed " << endl << "There is not Block of sufficient memory available!";
            return;
        }
    } else if (transaction == "B") {
        it = bestFit(blockSize);
        if (it == available.end()) {
            cerr << "Error: The attempt to allocate memory failed " << endl << "There is not Block of sufficient memory available!";
            return;
        } else {
            cout << "Found a block of memory of size " << (*it)->blockSize << endl;
            cout << "Success in allocating a block" << endl;
        }
    }
    allocate(it, processID, blockSize, processName);
}


list<Memory*>::iterator firstFit(int requiredBlockSize) {
    list<Memory*>::iterator it = available.begin();

    while (it != available.end()) {
        Memory *current = *it;
        if (current->blockSize >= requiredBlockSize) {
            cout << endl << "Sufficient memory block found. Size: " << current->blockSize << endl;
            cout << "Allocating Memory to block was successful!" << endl;
            return it;
        }
        it++;
    }
    return it;
}


list<Memory*>::iterator bestFit(int requiredBlockSize) {
    list<Memory*>::iterator it = available.begin();
    list<Memory*>::iterator minIterator = available.end();

    int minValue = numeric_limits<int>::max();

    while (it != available.end()) {
        Memory *currentBlock = *it;

        int currentBlockSize =currentBlock->blockSize;

        if (currentBlockSize >= requiredBlockSize) {
            if (currentBlockSize < minValue) {
                minIterator = it;
                minValue = (*minIterator)->blockSize;
            }
        }
        it++;
    }
    return minIterator;
}


Memory* findProcess(string processID, string processName) {
    for (list<Memory*>::iterator it = inUse.begin(); it != inUse.end(); it++) {
        Memory *currentBlock = *it;
        if ((currentBlock->processID == processID) && (currentBlock->memoryBlockID == processName)) {
            inUse.erase(it);
            return currentBlock;
        }
    }
    return nullptr;
}


void attach(Memory *memory) {
    for (list<Memory*>::iterator it = available.begin(); it != available.end(); it++) {
        Memory *currentBlock = *it;

        if (currentBlock->firstArea > memory->firstArea) {
            available.insert(it, memory);
            return;
        }
    }
}


void deallocate(string processID, string processName, string transaction) {
    Memory *memory;

    memory = findProcess(processID, processName);

    if (memory == nullptr) {
        cerr << endl << "Error: Attempt to deallocate memory failed." << endl;
        return;
    }

    attach(memory);
    regulate();

    if (transaction == "D") {
        cout << endl << endl << "Memory is found!" << endl << "Deallocation of memory was successful!" << endl;
    }
}

void cancelProcess(string processID) {
    list<Memory*>::iterator it = inUse.begin();
    bool processFound = false;

    while (it != inUse.end()) {
        Memory *currentMemory = *it;
        if (currentMemory->processID == processID) {
            processFound = true;
            it++;
            deallocate(processID, currentMemory->memoryBlockID, "T");
        } else {
            it++;
        }
    }

    if (processFound) {
        cout << "Process " << processID << " successfully terminated" << endl;
    } else {
        cerr << "Error: Attempt to terminate process failed!" << endl;
    }
}

void printList(list<Memory*> inList) {
    int size = 0;

    if (!inList.empty()) {


        for (list<Memory*>::iterator it = inList.begin(); it != inList.end(); it++) {
            Memory *currentMemory = *it;

            size += currentMemory->blockSize;
            cout << endl <<"Start Address = " << setw(5 ) << currentMemory->firstArea << " Size = " << setw(5) << currentMemory->blockSize << endl;
        }
    } else {
        cout << endl << "(NONE)" << endl;
    }

    cout << "Total size of the list = " << size << endl;
}

void printInUseList(list<Memory*> inUse) {
    int size = 0;

    if (!inUse.empty()) {

        for (list<Memory*>::iterator it = inUse.begin(); it != inUse.end(); it++) {
            Memory *currentMemory = *it;

            size += currentMemory->blockSize;
            cout << endl <<"Start Address = " << setw(10) << currentMemory->firstArea << " Size = " << setw(5) << currentMemory->blockSize << " Process ID = " << currentMemory->processID << " Block ID = " << currentMemory->memoryBlockID << endl;
        }
    } else {
        cout << endl << "(NONE)" << endl;
    }

    cout << "Total size of the list = " << size << endl;
}


void read(const string& type) {
    ifstream inFile;
    inFile.open("data6.txt");

    if (inFile.fail()) {
        cerr << "ERROR: Couldn't open file!" << endl;
        exit(-1);
    }

    processTitle(type);

    string line;

    while (getline(inFile, line)) {
        if (line == "?") {
            break;
        }

        cout << endl << "List of available blocks";
        printList(available);

        cout << endl << endl << "List of blocks currently in use";
        printInUseList(inUse);
        processLine(line, type);
    }

}

void initialize() {
    Memory *memory1 = new Memory(3 * MB, MB);
    Memory *memory2 = new Memory(4 * MB, 2 * MB);
    Memory *memory3 = new Memory(6 * MB, 2 * MB);
    Memory *memory4 = new Memory(8 * MB, 4 * MB);
    Memory *memory5 = new Memory(12 * MB, 4 * MB);

    available.push_back(memory1);
    available.push_back(memory2);
    available.push_back(memory3);
    available.push_back(memory4);
    available.push_back(memory5);
}

void processTitle(string type) {
    if (type == "B") {
        cout << endl << "Simulation of Memory Management using the Best-Fit algorithm" << endl;
    } else if (type == "F") {
        cout << endl << "Simulation of Memorry Management using the First-Fit algorithm" << endl;
    } else {
        cerr << "Error: Invalid arguments, Use B or F Please" << endl;
        exit(-1);
    }

    cout << endl << "Beginning of the Run." << endl;
}


void cancelCall() {
    cout << endl << endl << "End of the Simulation!" << endl << endl << "List of available blocks";

    printList(available);

    cout << endl << "List of blocks currently in use";

    printList(inUse);
}

