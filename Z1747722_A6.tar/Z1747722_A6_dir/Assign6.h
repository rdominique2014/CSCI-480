/* ASSIGN6*/




#include "Memory.h"
#include <iomanip>
#include <iostream>
#include <fstream>
#include <limits>
#include <sstream>
#include <cstdlib>
#include <string>

using namespace std;

#define HOW_OFTEN 5
#define MB 1024*1024
#define KB 1024

list<Memory*> inUse;
list<Memory*> available;

Memory* findProcess(string, string);

list<Memory*>::iterator firstFit(int);
list<Memory*>::iterator bestFit(int);
void printList(list<Memory*>);
void processTitle(string);
void cancelCall();
void initialize();
void allocate(list<Memory*>, string, int, string);
void attach(Memory*);
void regulate();
void load(string, int, string, string);
void deallocate(string, string, string);
void cancelProcess(string);
void read(const string&);
void processLine(string, string);
void printInUseList(list<Memory*>);



