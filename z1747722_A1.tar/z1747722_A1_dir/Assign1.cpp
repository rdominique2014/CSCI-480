/*Robert Dominique
CSCI 480 Assignment 1
08/30/19
*/


/*Print a message identifying the process as the original process
   and providing its PID and its parent's PID.

   Call fork() after printing a message saying you are about to do
   so.
   If fork() fails, print an error message ("The first fork failed.")
   and exit with a status of -1.
   If fork() succeeds, we now have two processes:  parent and child.

   In the child process:

   (a) Print a message identifying it as the child and providing its
       PID and its parent's PID.

   (b) Call fork() a second time after printing a message saying you
       are about to do so.

   (c) If fork() fails, print an error message ("The second fork
       failed.") and exit as above.

   (d) If fork() succeeds, we now have three processes:  one parent,
       one child and one grandchild.

       In the grandchild process:

       (i) Print a message identifying it as the grandchild and
           providing its PID and its parent's PID.

       (ii) Print a message saying it is about to exit.

       (iii) Exit with a status of 0.

       In the child process (after the second fork):

       (i) Print a message identifying it as the child and
           providing its PID and its parent's PID.

       (ii) Use wait(0) to wait for the grandchild to terminate.

       (iii) Print a message saying it is about to exit.

       (iv) Exit with a status of 0.

  In the parent process:

    (a) Print a message identifying it as the parent and providing
        its PID and its parent's PID.

    (b) Call the sleep() function to sleep for 2 seconds.

    (c) Print a message saying it is about to call ps.

    (d) Use system() to execute the "ps" command.

    (e) Use wait(0) to wait for the child to terminate.

    (f) Print a message saying it is about to terminate.

    (g) Exit with a status of 0.

    The overall program should return a value of 0. */

 #include <iostream>
 #include <sys/types.h>
 #include <sys/wait.h>
 #include <unistd.h>
 #include <stdlib.h>
 #include <stdio.h>
 using namespace std;

 int main() {

	pid_t pid;

cerr << "I am the original process. My PID " << getpid() << " and my parent's PID is " << getppid() << endl;

    cerr << "Now we have the first fork." << endl;

    pid = fork(); // create child

    if (pid < 0) {
        cerr << "The first fork failed." << endl;
        exit(-1);
    }
    else if (pid == 0) {
        cerr << "I am the child. My PID " << getpid() << " and my parent's PID is " << getppid() << endl;
        cerr << "Now we have the second fork." << endl;

        pid = fork();

        if (pid < 0) {
            cerr << "The second fork failed." << endl;
            exit(-1);
        }
	// grandchild process
        else if (pid == 0) {
            cerr << "I am the grandchild. My PID " << getpid() << " and my parent's PID is " << getppid() << endl;
            cerr << "I am the grandchild about to exit." << endl;

            exit(0);
        }
          //child process and parent process
        else {
            cerr << "I am still the child. My PID " << getpid() <<" and my parent's PID " << getppid() << endl;

            wait(0);

            cerr << "I am still the child about to exit." << endl;
            exit(0);
        }
    }
       //parent process
    else {
        cerr << "I am the parent. My PID " << getpid() << " and my parent's PID " << getppid() << endl;
        sleep(2);

        cerr << "I am the parent about to call ps." << endl;
        system("ps");

        wait(0);
        cerr << "I am the parent about to exit." << endl << endl;

        exit(0);
    }

    return 0;
}

