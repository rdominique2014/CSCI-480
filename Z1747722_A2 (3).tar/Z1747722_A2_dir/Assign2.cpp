/* Robert Dominique
   CSCI 480
   Z1747722
 Due 09/17/19
*/

/*

1. Declare three pipe variables (which I will call Pipe A, Pipe B and
   Pipe C).  Each is an array of two integers.

2. Call the pipe() function once for each pipe variable.

3. If any use of pipe() fails (returning -1), print an error
   message (such as "pipe #1 error") and exit with a status of -5.

4. Call the fork() function twice to create the three processes:
   once in the parent and then again in the child.  Do not create
   more than 3 processes.

   If fork() fails (returning -1), print an error message (such as
   "fork #2 error") and exit with a status of -5.

5. At this point we have three processes, parent, child and
   grandchild.  Each of these should call a function to do the rest
   of its work.  We can call these PWork() for the parent, CWork()
   for the child and GWork() for the grandchild.  Before calling its
   function, each process should close the ends of the pipes it will
   not use.  (The parent reads from Pipe C and writes to Pipe A, so
   it should close the write end of Pipe C and the read end of Pipe
   A, and both ends of Pipe B.)

   When the functions end, the processes should close the remaining
   ends of the pipes and then exit with a status of 0.  (The child
   should use wait() to wait until the grandchild terminates, and the
   parent should do the same for the child.)

6. Return a value of 0.  (This is not really needed as we are using
   exit(), but it's a good habit.)

*/




#include <iostream>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ios>
#include <iomanip>
using namespace std;

#define BUFFER_SIZE 15
#define READ_END 0
#define WRITE_END 1
#define PIPE_ARRAY_SIZE 2

char READ_MSG[BUFFER_SIZE];
char WRITE_MSG[BUFFER_SIZE];
long M;

void const PWork(int (&_pipeC)[2], int (&_pipeA)[2]);
void const CWork(int (&_pipeA)[2], int (&_pipeB)[2]);
void const GWork(int (&_pipeB)[2], int (&_pipeC)[2]);
void const algorithm(int (&readFromPipe)[2], int (&writeToPipe)[2], const int processNumber);

int main() {


    strcpy(READ_MSG, "1");
    M = 1;

    int pipeA[PIPE_ARRAY_SIZE], pipeB[PIPE_ARRAY_SIZE], pipeC[PIPE_ARRAY_SIZE];

    if (pipe(pipeA) == -1) {
        cout << "First pipe failed." << endl;
        return -1;
    }

    if (pipe(pipeB) == -1) {
        cout << "Second piple failed." << endl;
        return -1;
    }
    if (pipe(pipeC) == -1) {
        cout << "Third pipe failed." << endl;
        return -1;
    }

    pid_t pid = fork();

    if (pid < 0) {
        cout << "1st fork failed." << endl;
        return -1;
    } else if (pid == 0) {
        pid = fork();

        if (pid < 0) {
            cout << "Second fork failed." << endl;
            return -1;
        } else if (pid == 0) { //Grandchild process
            close(pipeB[WRITE_END]);
            close(pipeC[READ_END]);

            GWork(pipeB, pipeC);

            close(pipeB[READ_END]);
            close(pipeC[WRITE_END]);

            exit(0); //exit the grandchild
        }
        else { //child process
            close(pipeA[WRITE_END]);
            close(pipeB[READ_END]);

            CWork(pipeA, pipeB);

            close(pipeA[READ_END]); //close the end of pipes
            close(pipeB[WRITE_END]);

            wait(NULL); // Wait for grandchild process to finish
            exit(0);
        }
    } else {     //parents process
        close(pipeC[WRITE_END]); //close the end of non-needed pipes
        close(pipeA[READ_END]);

        PWork(pipeC, pipeA);

        close(pipeC[READ_END]); // close the end of pipes
        close(pipeA[WRITE_END]);

        wait(NULL); //Wait for child process to finish
        exit(0); // exit parent process
    }


    return 0;
}


void const PWork(int (&_pipeC)[2], int (&_pipeA)[2]) {
    write(_pipeA[WRITE_END], READ_MSG, strlen(READ_MSG) + 1); //Write message to pipeA

    cout << "Parent: " << setw(20) << "Value = "; //Display parent with contents of READ_MSG

    for (unsigned i = 0; i < strlen(READ_MSG); i++) {
        cout << READ_MSG[i];
    }
    cout << endl;

    algorithm(_pipeC, _pipeA, 2);

}



void const GWork(int (&_pipeB)[2], int (&_pipeC)[2]) {
    algorithm(_pipeB, _pipeC, 1);
}




void const CWork(int (&_pipeA)[2], int (&_pipeB)[2]) {
    algorithm(_pipeA, _pipeB, 0);
}



void const algorithm(int (&readFromPipe)[2], int (&writeToPipe)[2], const int processNumber) {
    while (M < 99999999999) {
        read(readFromPipe[READ_END], READ_MSG, BUFFER_SIZE);

        M = atol(READ_MSG);

        M = ((3 * M) + 7); // calculation for M

        string tempMessage = to_string(M); //Convert the integer into a string

        write(writeToPipe[WRITE_END], strcpy(WRITE_MSG, tempMessage.c_str()), tempMessage.length() + 1);

        switch (processNumber) {
            case 0:
                cout << "Child: " << setw(21) << "Value = " << M << endl;
                break;
            case 1:
                cout << "Grandchild: " << setw(16) << "Value = " << M << endl;
                break;
            case 2:
                cout << "Parent: " << setw(20) << "Value = " << M << endl;
            default:
                break;
        }
    }
}

