/* Robert Dominique
   z1747722
   Csci 480 01
Due 10/25/2019



We will have several consumer threads and several producer threads and one buffer. Each producer creates widgets and inserts them into the buffer, one at a time. Each consumer removes widgets from the buffer, one at a time. As the buffer is a fixed size, we need to ensure that:

(a) no producer tries to insert a widget into the buffer when it is full, and

(b) no consumer tries to remove a widget from the buffer when it is empty.

For our purposes, a widget is a small object as described below.  The buffer is a queue of widgets.  Each time we add something to the queue or remove something from the queue, we will print out the list of widgets now in the queue.  We will maintain an integer called Counter to keep track of how many widgets are in the buffer at any moment:  add 1 to Counter when we insert a Widget and subtract 1 from Counter when we remove a Widget.

We do not want to have two threads attempting to change the value of the counter at the same time, so we will use a mutex to limit access to it. Thus we can describe the actions as:

Insert a widget:
   Lock the mutex
   Add the widget to the buffer
   Increment Counter
   Unlock the mutex

Remove a widget:
   Lock the mutex
   Remove a widget from the buffer
   Decrement Counter
   Unlock the mutex
We will also use two semaphores, NotFull and NotEmpty. Before we start, NotFull is initalized to BUFFER_SIZE and NotEmpty is initialized to 0. (The textbook refers to NotFull and NotEmpty as Empty and Full, respectively.)

If NotFull is not 0, (think of that as "true") then the buffer is not full, so there is space left in the buffer and a producer can insert a widget. If NotFull is 0 (think of that as "false"), then the buffer is full, so the producer must wait until NotFull is positive before it can insert a widget and then decrement NotFull.  

If NotEmpty is not 0 (think of that as "true"), then the buffer is not empty, so there is at least one Widget in the buffer and a consumer can remove a widget. If NotEmpty is 0 (think of that as "false"), then the buffer is empty and the consumer must wait until NotEmpty is not 0 before it can remove an object and then decrement NotEmpty.

Notice that whenever we insert or remove a widget, Counter and NotFull and NotEmpty are all affected.

It may sound as if we have three counters for the buffer. In a sense, we do, but they are for different purposes. Everyone shares Counter. The NotFull semaphore is oriented to the producer's point of view: is there space to insert a widget? The NotEmpty semaphore is oriented to the consumer's point of view:  is there a widget to remove? The fact that these are semaphores gives us the convenience of the wait() function (go into a wait state instead of busy-waiting).

Here is what the producer is doing each tim
*/

#include <iostream>
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <semaphore.h>
#include <sys/sem.h>
using namespace std;

#define P_NUMBER 6
#define C_NUMBER 4
#define BUFFER_SIZE 12
#define N_P_STEPS 4
#define N_C_STEPS 6

//Function Prototypes
void insert(void *);
void remove(void *);
void* producer(void *);
void* consumer(void *);
void insert_widget(int);
void remove_widget(int);


sem_t NotFull, NotEmpty;
pthread_mutex_t mutex1;
int widgets = 0;

int main(int argc, char *argv[]) {
    cout << endl << "Simulation of Producer and Consumers" << endl << endl;

sem_init(&NotFull, 0, BUFFER_SIZE);// initalize NotFull
	sem_init(&NotEmpty, 0, 0);// initalize NotEmpty
	if (pthread_mutex_init(&mutex1, NULL) != 0) { // initalize lock and check if it failed
		printf("\n mutex init failed\n");
		return 1;
}




    pthread_t producerThread[P_NUMBER];
    pthread_t consumerThread[C_NUMBER];

    int consumerThreadNum = 0; //Create consumer threads
    for (long i = 0; i < C_NUMBER; i++) {
        consumerThreadNum = pthread_create(&consumerThread[i], NULL, consumer, (void*) i); 
        if (consumerThreadNum) {
            cerr << endl << "Failed: Creating consumer Threads" << endl;
            exit(-1);
        }
    }

    int producerThreadNum = 0; //Create producer threads
    for (long i = 0; i < P_NUMBER; i++) {
        producerThreadNum = pthread_create(&producerThread[i], NULL, producer, (void*) i);
        if (producerThreadNum) {
            cerr << endl << "Failed: Creating producer threads" << endl;
            exit(-1);
        }
    }
 
    int producerThreadJoinNum = 0; //Loop through all of the threads
    for (int i = 0; i < P_NUMBER; i++) {
        producerThreadJoinNum = pthread_join(producerThread[i], NULL);
        if (producerThreadJoinNum) {
            cerr << "Failed: Producer couldn't join thread" << endl;
            exit(-1);
        }
    }

    int consumerThreadJoinNum = 0; //Loop through all of the threads
    for (int i = 0; i < C_NUMBER; i++) {
        consumerThreadJoinNum = pthread_join(consumerThread[i], NULL); ////Wait for the target thread to to end
        if (consumerThreadJoinNum) {
            cerr << "Failed: Consumer couldn't join thread" << endl;
            exit(-1);
        }
    }

    cout << endl << "All the producer and consumer threads have been closed." << endl;


if(sem_destroy(&NotFull))
	{	// If failed, print error
		fprintf(stderr, "Falied to destroy semaphore not_full\n");
		exit(-1);
	}
	if(sem_destroy(&NotEmpty))
	{	// If failed, print error
		fprintf(stderr, "Falied to destroy semaphore not_empty\n");
		exit(-1);
	}
	if(pthread_mutex_destroy(&mutex1))
	{	// If failed, print error
		fprintf(stderr, "Falied to destroy mutex counter_lock\n");
		exit(-1);
	}

    cout << endl << "The semaphores and mutex have been deleted." << endl << endl;
    return 0;
}

/******************************
function: insert(void *)
returns: Nothing
This function adds one item to the buffer and shows who added it
*******************************/
void insert(void* producerID ) {
pthread_mutex_lock(&mutex1);
 widgets++;
cout << "Producer " << (long)producerID << " inserted one item. Total is now " << widgets << endl;
pthread_mutex_unlock(&mutex1);

}

/******************************
 function: remove(void *)
 returns: Nothing
 This function deletes one item to the buffer and shows who removed it
 *******************************/
void remove(void *consumerID) {
    pthread_mutex_lock(&mutex1);
    widgets--;
    cout << "Consumer " << (long)consumerID << " inserted one item. Total is now " << widgets << endl;
    pthread_mutex_unlock(&mutex1);

}

/******************************
 function: producer(void *)
 returns: Nothing
 This function is called by the producer thread
 *******************************/
void* producer(void* producerID) {

    for (int i = 0; i < N_P_STEPS; i++) {
        sem_wait(&NotFull);
        insert(producerID);
        sem_post(&NotEmpty);
        sleep(1);
    }
    pthread_exit(NULL);
}

/******************************
 function: consumer(void *)
 returns: Nothing
 This function is called by the consumer thread
 *******************************/
void* consumer(void* consumerID) {
    for (int i = 0; i < N_C_STEPS; i++) {
        sem_post(&NotEmpty);
        remove(consumerID);
        sem_post(&NotFull);
        sleep(1);
    }
    pthread_exit(NULL);
}

