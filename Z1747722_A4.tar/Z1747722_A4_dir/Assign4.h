#ifndef Assign4_h
#define Assign4_h
#define MAX_TIME 500
#define AT_ONCE 6
#define QUEUE_SIZE 20
#define HOW_OFTEN 25

#include "Process.h"
#include <queue>
#include <fstream>

using std::queue;
using std::priority_queue;
using std::vector;
using std::ifstream;

struct Compare {
public:
    bool operator() (Process *left, Process *right) {
        return left->priority < right->priority;
    }
};

bool condition(int);

void printProcessValues();
void printQueue(queue<Process*>);
void printPriorityQueue(priority_queue<Process *, vector<Process *>, Compare>);
void printResults();

void moveToQueue(Process*&, string, bool);
void completeBurst(Process*&, History, unsigned int&, int &, bool);
void activateProcess(Process*&, priority_queue<Process*, vector<Process*>, Compare>&);
void endProcess(Process*& );

void readFile();
void setProcess(Process* , const char*);
void setProcessHistory(Process*, const char*);

History getProcessHistory(Process* );

Process *Active = nullptr;
Process *IActive = nullptr;
Process *OActive = nullptr;

queue<Process *> entryQueue;
priority_queue<Process *, vector<Process *>, Compare> readyQueue;
priority_queue<Process *, vector<Process *>, Compare> inputQueue;
priority_queue<Process *, vector<Process *>, Compare> outputQueue;

int process = 0;
unsigned int timer = 0;

#endif

