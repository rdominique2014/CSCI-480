/* Robert Dominique
   z1747722
   Csci 480
  Due October 14,2019

In this assignment, we are simulating priority scheduling of processes on a single-processor system, without preemption.  The idea is that when a process ends its CPU burst (or input burst or output burst), it is succeeded by the highest-priority process that is waiting.  

For the sake of this assignment, we will make a few simplifying
assumptions such as:

(a) We will assume the processes engage in CPU bursts, Input bursts and Output
    bursts and ignore any possible interrupts.

(b) We will assume that all processes are doing Input through the same device
    which can process one Input burst at a time.

(b) We will assume that all processes are doing Output through the same device
    which can process one Output burst at a time.

(c) We will assume the system starts out with no processes active. There may
    be processes ready to start at once.

(d) We are ignoring the context-switching time.

(e) The array called History (described below) is a convenience.
alternative would be to generate the data dynamically using random
numbers.  Let's not do that; this is complicated enough.)

The events are governed by a timer which is simply counting clock ticks.  (For our purposes, a clock tick might be one millisecond).

A description of the input file is provided below.

Write a program in C or C++ on the turing system to accomplish this.

In your program, you will need a struct or class to represent a Process; you will need a struct or class to implement a queue; and you will need a struct or class to implement priority queues.  The items stored in the queue and priority queues are pointers to processes.  You may also need a struct for entries in the History array.

The program requires 4 queues (including priority queues):  Entry, Ready, Input and Output.  We will also have variables Active, IActive, and OActive, which are pointers to processes.  

The Entry queue is an ordinary queue:  First-In-First-Out.  The other three are “priority queues”, that is, when we pop a process off the queue, it is the highest-priority process in the queue.  If two processes have the same priority, the one which has been waiting longer should be next.  Figure out a way to implement this.
*/



#include "Assign4.h"

int main()
{
    readFile();

    int processe = 0;
    int TimeCount = 0;

    while (condition(timer)) {
        while (processe < AT_ONCE) {
            if (entryQueue.empty()) {
                break;
            }
            Process* processToMove = entryQueue.front(); //Grab process object of entry queue

            if (processToMove->arrivalTime > timer) {
                break;
            }
            entryQueue.pop();
            cout << endl << "Process " << processToMove->processName << " moved from the Entry to Ready at time: " << timer << endl;

            processToMove->arrivalTime = timer; //set the arrival time of the Process

            readyQueue.push(processToMove);
            processe++;
        }

        if (timer % HOW_OFTEN == 0) {
            printResults();
        }

        activateProcess(Active, readyQueue);

        if (Active == nullptr) {
            TimeCount++;
        } else {
            History current = getProcessHistory(Active);
            moveToQueue(Active, current.burstLetter, false);
            completeBurst(Active, current, Active->CPUTimer, processe, false);

            if (Active != nullptr) {
                Active->CPUTotal++;
                Active->CPUTimer++;
            }
        }

        activateProcess(IActive, inputQueue);

        if (IActive != nullptr) {
            History currentInputHistory = getProcessHistory(IActive);

            completeBurst(IActive, currentInputHistory, IActive->IOtimer, processe, true);

            if (IActive != nullptr) {
                IActive->ICount++;
                IActive->IOtimer++;
            }
        }

        activateProcess(OActive, outputQueue);

        if (OActive != nullptr) {
            History currentOutputHistory = getProcessHistory(OActive);

            completeBurst(OActive, currentOutputHistory, OActive->IOtimer, processe, true);

            if (OActive != nullptr) {
                OActive->IOtimer++;
                OActive->OCount++;
            }
        }
        timer++;
    }

    cout << endl << endl << endl << "******************************" << endl << "Program ended at time: " << timer << endl << "Total amount of time CPU was idle: " << TimeCount << endl << "Total amount of ended processes: " << process;
    printResults();

    return 0;

}


void setProcess(Process* processToSet, const char* inputLine) {
    char buffer[256];
    string processName;
    char* next;

    strcpy(buffer, inputLine); //grab process Name from buffer

    processName = strtok(buffer, " ");
    processToSet->processName = processName;

    next = strtok(NULL, " "); // grab ProcessPriority from the buffer
    processToSet->priority = atoi(next);

    next = strtok(NULL, " "); //grab ProcessArrivate from buffer
    processToSet->arrivalTime = atoi(next);
}


void completeBurst(Process*& movedProcess, History movedProcessStruct, unsigned int& inputTimer, int& processesCurrentlyUsed, bool isIOBurst) {
    if (movedProcess != nullptr) {
        if (inputTimer == movedProcessStruct.burstValue) {
            inputTimer = 0;
            movedProcess->sub++;
            if (isIOBurst) {
                if (movedProcessStruct.burstLetter == "I") {
                    movedProcess->ICount++;
                }
                if (movedProcessStruct.burstLetter == "O") {
                    movedProcess->OCount++;
                }
                moveToQueue(movedProcess, movedProcessStruct.burstLetter, isIOBurst);
                return;
            }
            movedProcessStruct = getProcessHistory(movedProcess);
            if (movedProcessStruct.burstLetter == "N") {
                movedProcess->CPUTotal++;
                endProcess(movedProcess);

                processesCurrentlyUsed--;
            } else {
                movedProcess->CPUTotal++;
                moveToQueue(movedProcess, movedProcessStruct.burstLetter, isIOBurst);
            }
        }
    }
}


void setProcessHistory(Process* inProcess, const char* next) {
    char buffer[256];
    int index = 0;

    strcpy(buffer, next);
    History* tempHistory = inProcess->history;

    char* burstInfo = strtok(buffer, " ");

    while (burstInfo != nullptr) {
        History* secondTempHistory = new History();

        secondTempHistory->burstLetter = burstInfo;

        burstInfo = strtok(NULL, " ");
        secondTempHistory->burstLetter = burstInfo;

        burstInfo = strtok(NULL, " ");
        secondTempHistory->burstValue = atoi(burstInfo);

        burstInfo = strtok(NULL, " ");

        tempHistory[index] = *secondTempHistory;
        index++;
    }
}


History getProcessHistory(Process* processHistory) {
    return processHistory->history[processHistory->sub];
}

void readFile() {
    string next;
    int idnumber = 100; // ID Number

    ifstream inFile("data4.txt");
    if (inFile.fail()) {
        cerr << "The text file could not open." << endl;
        return;
    }

    getline(inFile, next); //Reading the file
    while (inFile) {
        Process* temp = new Process(idnumber);
        setProcess(temp, next.c_str());

        if (temp->processName == "STOPHERE") {
            delete (temp);
            temp = nullptr;
            break;
        }

        entryQueue.push(temp);

        getline(inFile, next);
        setProcess(temp, next.c_str()); //Stores the line
        idnumber++; //increases ID counter

        getline(inFile, next);
    }
    inFile.close();
}


void endProcess(Process*& toEnd) {
    cout << endl << toEnd->processName << " ended at time: " << timer;
    toEnd->printInformation(); // Prints the information about the ending process
    process++; //Adds to the end of the process count
    delete toEnd; //delete
    toEnd = nullptr;
}


bool condition(int inTime) {
    return (inTime < MAX_TIME) and (!entryQueue.empty() or !readyQueue.empty() or !inputQueue.empty() or !outputQueue.empty() or
                                    Active != nullptr or IActive != nullptr or OActive != nullptr);
}


void activateProcess(Process*& activeState, priority_queue<Process*, vector<Process*>, Compare>& makeActive) {
    if (activeState == nullptr) {
        if (makeActive.size() > 0) {
            activeState = makeActive.top();
            makeActive.pop();
        }
    }
}


void moveToQueue(Process*& currentProcess, string nameQueue, bool backToReadyQueue) {
    if (backToReadyQueue) {
        readyQueue.push(currentProcess); //pushing into ready queue
        currentProcess = nullptr;
    } else if (nameQueue == "O") {
        outputQueue.push(currentProcess); // push into output Queue
        currentProcess = nullptr;
    } else if (nameQueue == "I") {
        inputQueue.push(currentProcess); //Push into input queue
        currentProcess = nullptr;
    } else {

    }
}


void printQueue(queue<Process*> inQueue) {
    if (inQueue.empty()) {
        cout << "This is empty!" << endl;
        return;
    }

    while (!inQueue.empty()) {
        Process *temp = inQueue.front();
        cout << temp->processName << " (ID: " << temp->processID << ")" << endl; //print information
        inQueue.pop();
    }
}

void printPriorityQueue(priority_queue<Process*, vector<Process*>, Compare> inPriorityQueue) {
    if (inPriorityQueue.empty()) {
        cout << "The priority Queue is empty" << endl;
        return;
    }

    while (!inPriorityQueue.empty()) {
        Process *temp = inPriorityQueue.top();
        cout << temp->processName << " (ID: " << temp->processID << ")" << endl;
        inPriorityQueue.pop(); //removing top object
    }
}



void printProcessValues() {
    cout << endl << "**************************" << endl << endl << "Status at timer is " << timer << endl;

    if (Active == nullptr) {
        cout << "Active: Empty" << endl;
    } else {
        cout << "Active: " << Active->processName << " (ID: " << Active->processID << ")" << endl;
    }

    if (IActive == nullptr) {
        cout << "IActive: Empty" << endl;
    } else {
        cout << "IActive: " << IActive->processName << " (ID: " << IActive->processID << ")" << endl;
    }

    if (OActive == nullptr) {
        cout << "OActive: Empty" << endl;
    } else {
        cout << "OActive: " << OActive->processName << " (ID: " << OActive->processID << ")" << endl;
    }
}

void printResults() {
    printProcessValues();

    cout << endl << "Entry Queue contains:" << endl;
    printQueue(entryQueue);

    cout << endl << "Ready Queue contains:" << endl;
    printPriorityQueue(readyQueue);

    cout << endl << "Input Queue containts:" << endl;
    printPriorityQueue(inputQueue);

    cout << endl << "Output Queue contains:" << endl;
    printPriorityQueue(outputQueue);
    cout << endl << "********************************" << endl;
}

