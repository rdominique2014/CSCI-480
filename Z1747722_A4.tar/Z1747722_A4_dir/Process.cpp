#include "Process.h"


void Process::printInformation() {
    cout << endl << "Name: " << this->processName << endl << "ID: " << this->processID << endl << "Priority: " << this->priority << endl << "Start time: " << this->arrivalTime << endl << "End time: " << timer << endl << "Time spent Active:  "<< this->CPUTotal << " in " << this->CPUTotal << " CPU bursts." << endl << "Time spent IActive: " << this->ICount << " in " << this->ICount << " Input bursts." << endl << "Time spent OActive: " << this->OCount << " in " << this->OCount << " Output bursts." << endl << "Time spent waiting: " << (timer - this->arrivalTime - this->CPUTotal - this->OCount - this->ICount) << endl;  //calculation to figure out how much was idle time"
}

