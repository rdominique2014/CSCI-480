#ifndef Process_h
#define Process_h
#define ARRAY_SIZE 10

#include <iostream>
#include <string.h>
#include <string>

using std::cout;
using std::endl;
using std::string;
using std::cerr;

extern unsigned int timer;

/*********************
 The History Struct has an array of pairs of the form (letter, value)
**********************/
struct History {
    unsigned int burstValue;
    string burstLetter;
};

class Process {
    public:
        Process(unsigned int newID) : processID(newID) {}

        string processName;
        unsigned int priority;
        unsigned int arrivalTime = 0;
        int processID;

        History history[ARRAY_SIZE];
        unsigned int sub;

        unsigned int CPUTimer = 0;
        unsigned int IOtimer = 0;
        unsigned int CPUTotal = 0;
        unsigned int ICount = 0;
        unsigned int OCount = 0;

        void printInformation();
};


#endif

